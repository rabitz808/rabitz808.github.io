// Copyright 2019 - Rafael Abitz
// Version 1.0

import java.util.Random;

public class Animal {

	EZImage animal;
	private int animalX, animalY, speed, direction;

	// Constructor for animal using y variable
	public Animal(int y) {
		animal = EZ.addImage("catright.png", 0, y);
		animalX = animal.getXCenter();
		animalY = animal.getYCenter();
		Random rg = new Random();
		speed = rg.nextInt(8) + 5;
	}
	
	// Check if the animal touches the player
	public boolean isTouching(int x, int y) {
		if (animal.isPointInElement(x, y))
			return true;
		else
			return false;
	}

	// Moves the animal
	public void move() {
		// If the direction is 0, move the animal right
		if (direction == 0) {
			animalX += speed;
		}

		// If the direction is 1, move the animal left
		if (direction == 1) {
			animalX -= speed;
		}

		// If the animal goes off the right side of the screen, 
		//change the direction, remove the old picture, and add in the new picture
		if (animalX > 1280) {
			direction = 1;
			EZ.removeEZElement(animal);
			animal = EZ.addImage("catleft.png", animalX, animalY);
		}

		// If the animal goes off the left side of the screen, 
		//change the direction, remove the old picture, and add in the new picture
		if (animalX < 0) {
			direction = 0;
			EZ.removeEZElement(animal);
			animal = EZ.addImage("catright.png", animalX, animalY);
		}

		// Move the animal to x and y coordinates
		animal.translateTo(animalX, animalY);
	}
}
