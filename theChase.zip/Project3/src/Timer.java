// Copyright 2019 - Charlotte Logan
// Version 1.2

import java.awt.Color;

public class Timer {

	EZText timerLabel;
	int minutes;
	int seconds;

	/**
	 * creates new timer, takes time as minutes
	 * 
	 * @param time
	 */
	public Timer(int time) {
		minutes = time;
		seconds = 1;
		timerLabel = EZ.addText(100, 50, minutes + ":0" + seconds, Color.white, 50);
	}

	/**
	 * ticks the timer down by 1 second, should be called whenever the framecount %
	 * 60 = 0
	 */
	public void tickDown() {
		if (seconds > 0) {
			seconds--;
		} else if (seconds == 0) {
			minutes--;
			seconds = 59;
		}
		if (seconds >= 10) {
			timerLabel.setMsg(minutes + ":" + seconds);
		} else if (seconds < 10) {
			timerLabel.setMsg(minutes + ":0" + seconds);
		}
		if ((minutes == 0) && (seconds == 0)) {
			timerLabel.hide();
		}
	}

	/**
	 * gets the minutes
	 * 
	 * @return
	 */
	public int getMinutes() {
		return minutes;
	}

	/**
	 * gets the seconds
	 * 
	 * @return
	 */
	public int getSeconds() {
		return seconds;
	}

	public boolean isTimeOut() {
		if (minutes == 0 && seconds == 0)
			return true;
		else
			return false;
	}
}
