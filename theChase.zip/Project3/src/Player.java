// Copyright 2019 - Charlotte Logan & Rafael Abitz
// Version 1.1

import java.awt.Color;

public class Player {

	EZImage avatar;
	private int x, y, speed, spriteWidth, spriteHeight, spriteDirection, walkSequence, cycleSteps, counter, lives;
	boolean alive;

	/**
	 * straightforward, you just gotta set the start position
	 * 
	 * @param x
	 * @param y
	 */
	public Player(int x, int y, int speed, int width, int height, int steps) {
		this.x = x;
		this.y = y;
		this.speed = speed;
		alive = true;
		lives = 3;
		spriteWidth = width;
		spriteHeight = height;
		cycleSteps = steps;
		avatar = EZ.addImage("player.png", x, y);
		avatar.setFocus(spriteDirection, walkSequence * spriteHeight, spriteDirection + spriteWidth,
				walkSequence * spriteHeight + spriteHeight);
	}

	/**
	 * this one is fun, just invoke the function with a string of the direction you
	 * want all lowercase, up course you can do "up", "down", "left", or "right"
	 * 
	 * @param direction
	 */
	public void move(String direction) {
		switch (direction) {
		case "up":
			y -= speed;
			spriteDirection = spriteWidth * 2;

			if ((counter % cycleSteps) == 0) {
				walkSequence--;
				if (walkSequence < 0)
					walkSequence = 2;
			}
			counter++;
			break;
		case "down":
			y += speed;
			spriteDirection = spriteWidth;
			if ((counter % cycleSteps) == 0) {
				walkSequence++;
				if (walkSequence > 2)
					walkSequence = 0;
			}
			counter++;
			break;
		case "left":
			x -= speed;
			spriteDirection = 0;
			if ((counter % cycleSteps) == 0) {
				walkSequence--;
				if (walkSequence < 0)
					walkSequence = 2;
			}
			counter++;
			break;
		case "right":
			x += speed;
			spriteDirection = spriteWidth * 3;

			if ((counter % cycleSteps) == 0) {
				walkSequence++;
				if (walkSequence > 2)
					walkSequence = 0;
			}
			counter++;
			break;
		}

		avatar.translateTo(x, y);
		avatar.setFocus(spriteDirection, walkSequence * spriteHeight, spriteDirection + spriteWidth,
				walkSequence * spriteHeight + spriteHeight);
	}

	public void stop() {
		if (EZInteraction.isKeyDown("d")) {
			x = x - 2;
		}
		if (EZInteraction.isKeyDown("w")) {
			y = y + 2;
		}
		if (EZInteraction.isKeyDown("a")) {
			x = x + 2;
		}
		if (EZInteraction.isKeyDown("s")) {
			y = y - 2;
		}
	}

	/**
	 * gets the x coord
	 * 
	 * @return
	 */
	public int getX() {
		return x;
	}

	/**
	 * gets the y coord
	 * 
	 * @return
	 */
	public int getY() {
		return y;
	}

	/**
	 * checks living/dead status
	 * 
	 * @return
	 */
	public boolean isAlive() {
		return alive;
	}

	/**
	 * performs death actions for the player if they die
	 */
	public void die() {
		lives--;
		x = 720;
		y = 720;
		avatar.translateTo(x, y);
	}

	public int getLives() {
		return lives;
	}

	public void lose() {
		alive = false;
		EZ.removeAllEZElements();
		EZ.addText(EZ.getWindowWidth()/2, EZ.getWindowHeight()/2, "YOU LOSE", Color.black, 50);
	}

	public void win() {
		alive = false;
		EZ.removeAllEZElements();
		EZ.addText(EZ.getWindowWidth()/2, EZ.getWindowHeight()/2, "YOU WIN", Color.black, 50);
	}
}
