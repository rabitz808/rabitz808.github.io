// Copyright 2019 - Charlotte Logan
// Version 1.0

public class NoFlyZone {

	EZRectangle collision;

	/**
	 * the default constructor, just takes regular parameters
	 * 
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	public NoFlyZone(int x, int y, int width, int height) {
		collision = EZ.addRectangle(x, y, width, height, null, false);
		collision.setLayer(0); // i think 0 is below all other layers but i dont remember
	}

	/**
	 * the advanced constructor that you can feed a specific EZ element into, like
	 * if ur doing a building
	 * 
	 * @param element
	 */
	public NoFlyZone(EZElement element) {
		collision = EZ.addRectangle(element.getXCenter(), element.getYCenter(), element.getWidth(), element.getHeight(),
				null, false);
		collision.setLayer(0);
	}

	/**
	 * checks for touching, should only take player's coordinates
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean isTouching(int x, int y) {
		if (collision.isPointInElement(x, y))
			return true;
		else
			return false;
	}
}
