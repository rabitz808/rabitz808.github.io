
// Copyright 2019 - Charlotte Logan & Rafael Abitz
// Version 1.4
/*
 * Charlotte Logan created classes Car, Collectible, Player, NoFlyZone, and Timer
 * Rafael created class Animal, as well as the Main
 * 
 * Player.java received input from both members
 * 
 * While Rafael authored most of the main class, some revisions and some of the overall 
 * design were made by Charlotte
 * 
 * The two concepts are ArrayLists, and Private, public member variables and member 
 * functions
 * 
 * Instructions for operation: use WASD to move. dodge obstacles, collect coins, go to 
 * red building once all coins are collected
 */

import java.util.*;

public class Main {

	public static void main(String[] args) {
		// Initialize the map
		EZ.initialize(1280, 736);
		EZ.addImage("Mapv2.png", 1280 / 2, 736 / 2);

		// Create a player
		Player student = new Player(720, 720, 2, 16, 32, 10);

		// Create a timer
		Timer countdown = new Timer(2);

		// Make an array for building collisions
		NoFlyZone[] buildings = new NoFlyZone[8];

		// Add collision zones for each building
		buildings[0] = new NoFlyZone(296, 152 - 8, 144 + 8, 112 + 8);
		buildings[1] = new NoFlyZone(1096, 152 - 8, 144 + 8, 112 + 8);
		buildings[2] = new NoFlyZone(120, 536 - 8, 144 + 8, 112 + 8);
		buildings[3] = new NoFlyZone(736, 152 - 8, 96 + 8, 112 + 8);
		buildings[4] = new NoFlyZone(912, 536 - 8, 96 + 8, 112 + 8);
		buildings[5] = new NoFlyZone(472, 536 - 8, 208 + 8, 112 + 8);
		buildings[6] = new NoFlyZone(1192, 560 - 8, 48 + 8, 64 + 8);
		buildings[7] = new NoFlyZone(744, 32 - 8, 336 + 8, 64 + 8);

		// Make an array for collectibles
		Collectible[] coin = new Collectible[3];
		coin[0] = new Collectible("coin.png", 592);
		coin[1] = new Collectible("coin.png", 320);
		coin[2] = new Collectible("coin.png", 80);

		// Make an array for hearts
		EZImage[] hearts = new EZImage[3];
		hearts[0] = EZ.addImage("heart.png", 200, 50);
		hearts[1] = EZ.addImage("heart.png", 225, 50);
		hearts[2] = EZ.addImage("heart.png", 250, 50);

		// Make an array list of cars
		ArrayList<Car> carList = new ArrayList<Car>();

		// Make an array list of animals
		ArrayList<Animal> animalList = new ArrayList<Animal>();

		// Spawn in animals and add them to the array list
		Animal cat = new Animal(320);
		Animal cat1 = new Animal(215);
		Animal cat2 = new Animal(599);
		Animal cat3 = new Animal(368);
		Animal cat4 = new Animal(80);
		Animal cat5 = new Animal(688);
		animalList.add(cat);
		animalList.add(cat1);
		animalList.add(cat2);
		animalList.add(cat3);
		animalList.add(cat4);
		animalList.add(cat5);

		// Counter for spawning cars
		int counter = 0;

		// Counter for coins
		int score = 0;

		// Main Code
		while (student.isAlive()) {
			if (counter % 60 == 0) {
				countdown.tickDown();
			}
			if (counter > 6000)
				counter = 0;
			else
				counter++;

			// Spawn in cars once the counter reaches a certain number and add them to the
			// array list
			if (counter % 150 == 0) {
				Car Car1 = new Car(240, "carorange.png");
				Car Car2 = new Car(432, "carorange.png");
				Car Car3 = new Car(624, "carorange.png");
				Car Car4 = new Car(272, "cargrey.png");
				Car Car5 = new Car(464, "cargrey.png");
				Car Car6 = new Car(656, "cargrey.png");
				carList.add(Car1);
				carList.add(Car2);
				carList.add(Car3);
				carList.add(Car4);
				carList.add(Car5);
				carList.add(Car6);
			}

			// Loop through carList array and make each car move
			// Removes the car from the array list once it reaches the end of the screen
			for (int i = 0; i < carList.size(); i++) {
				Car eachCar = carList.get(i);
				eachCar.drive();
				if (eachCar.isDriving() == false) {
					carList.remove(eachCar);
				}
				// If a car touches the player, the player dies
				if (eachCar.isTouching(student.getX(), student.getY())) {
					student.die();
				}
			}

			// Loop through the animalList array and make each animal move
			for (int i = 0; i < animalList.size(); i++) {
				Animal eachAnimal = animalList.get(i);
				eachAnimal.move();
				// If an animal touches the player, the player dies
				if (eachAnimal.isTouching(student.getX(), student.getY())) {
					student.die();
				}
			}

			move(student);

			// Check each building to see if its touching the player and make sure the
			// player cant pass it
			for (int i = 0; i < 8; i++) {
				if (buildings[i].isTouching(student.getX(), student.getY())) {
					student.stop();
				}
				// If you have collected all the coins and touch the building you win!
				if ((buildings[7].isTouching(student.getX(), student.getY())) && (score == 3)) {
					student.win();
				}
			}

			// If the timer reaches 0 you lose
			if (countdown.isTimeOut() || student.getLives() < 0) {
				carList.clear();
				animalList.clear();
				EZ.removeAllEZElements();
				student.lose();
			}

			// Hide hearts after each death
			if (student.getLives() == 2) {
				hearts[2].hide();
			} else if (student.getLives() == 1) {
				hearts[1].hide();
			} else if (student.getLives() == 0) {
				hearts[0].hide();
			}

			// Hide coins after touching and add 1 to the score
			for (int i = 0; i < 3; i++) {
				if (coin[i].isTouching(student.getX(), student.getY()) && coin[i].isVisible()) {
					coin[i].hide();
					score++;
				}
			}
			EZ.refreshScreen();
		}
	}

	/**
	 * moves player
	 * 
	 * @param e
	 */
	static public void move(Player e) {
		if (EZInteraction.isKeyDown("d")) {
			e.move("right");
		} else if (EZInteraction.isKeyDown("a")) {
			e.move("left");
		} else if (EZInteraction.isKeyDown("w")) {
			e.move("up");
		} else if (EZInteraction.isKeyDown("s")) {
			e.move("down");
		}
	}

}
