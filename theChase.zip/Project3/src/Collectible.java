// Copyright 2019 - Charlotte Logan
// Version 1.0

import java.util.Random;

public class Collectible {

	EZImage collectible;

	int xPos, yPos;
	boolean visible = false;

	/**
	 * creates new collectible
	 * 
	 * @param filename
	 * @param x
	 * @param y
	 */
	public Collectible(String filename, int y) {
		Random rg = new Random();
		xPos = rg.nextInt(1000) + 50;
		// xPos = x;
		yPos = y;
		collectible = EZ.addImage(filename, xPos, yPos);
		collectible.scaleBy(0.4);
		visible = true;
	}

	/**
	 * moves collectible to point of your choosing
	 * 
	 * @param x
	 * @param y
	 */
	public void move(int x, int y) {
		collectible.translateTo(x, y);
	}

	/**
	 * returns the x position
	 * 
	 * @return
	 */
	public int getX() {
		return xPos;
	}

	/**
	 * returns the y position
	 * 
	 * @return
	 */
	public int getY() {
		return yPos;
	}

	/**
	 * hides the collectible
	 */
	public void hide() {
		collectible.hide();
		visible = false;
	}

	/**
	 * shows the collectible
	 */
	public void show() {
		collectible.show();
		visible = true;
	}

	/**
	 * checks visibility of collectible
	 * 
	 * @return
	 */
	public boolean isVisible() {
		if (visible)
			return true;
		else
			return false;
	}

	public boolean isTouching(int x, int y) {
		if (collectible.isPointInElement(x, y))
			return true;
		else
			return false;
	}
}
