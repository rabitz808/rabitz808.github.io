// Copyright 2019 - Charlotte Logan
// Version 1.0

import java.util.Random;

public class Car {

	EZImage car;
	int carX, carY, speed;

	/**
	 * constructor for the car, it appears off the right edge of the screen, but
	 * requires a y coord for height
	 * 
	 * @param y
	 * @param filename
	 */
	public Car(int y, String filename) {
		car = EZ.addImage(filename, 1300, y);
		carX = car.getXCenter();
		carY = car.getYCenter();
		Random rg = new Random();
		speed = rg.nextInt(10) + 5;
	}

	/**
	 * nudges the car to the left
	 */
	public void drive() {
		carX -= speed;
		car.translateTo(carX, carY);

		if (carX < -50) {
			finalize();
		}
	}

	public boolean isDriving() {
		if (carX < -50) {
			return false;
		} else
			return true;
	}

	/**
	 * checking for if the player character touches the car Note: u pretty much only
	 * use the player's x and y
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean isTouching(int x, int y) {
		if (car.isPointInElement(x, y))
			return true;
		else
			return false;
	}

	public void finalize() {
		EZ.removeEZElement(car);
	}
}
